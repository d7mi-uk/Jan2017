package co2001;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class UsersManager  {

	List<User> users = new ArrayList<User>();
	
	
	//Adds a new opject to the List users using the current data members
	public void addUser(String un, String pw, String em, int ag){
		User toAdd = new User(un, pw, em, ag);
		toAdd.setId(users.size());
		users.add(toAdd);
		
	}
	
	public List<User> getUsers() {
		return users;
	}
	
	// Using Serializable
	
	public void read(){
		
		try{
			ObjectInputStream ois = new ObjectInputStream(new FileInputStream("resources/source"));
			users = (List) ois.readObject();
			ois.close();
		}catch(Exception e){
			e.getMessage();
		}
		
	}
	
	public void write(){
		try{
			ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("resources/source"));
			oos.writeObject(users);
			oos.close();
		}catch(Exception e){
			e.getMessage();
		}	
	}
	
}

package co2001;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class MoviesManager {
	
	public List <Movie> moviesList = new ArrayList <Movie>();
	
	// ADDING THE 10 Movie TO THE LIST
		public void fillList(){
//			moviesList.add(new Movie(86644, "Fast Five","2011", "Action|Crime|Drama|Thriller|IMAX"));
//			moviesList.add(new Movie(86911, "The Hangover Part II", "2011", "Comedy"));
//			moviesList.add(new Movie(2959, "Fight Club", "1999", "Action|Crime|Drama|Thriller"));
//			moviesList.add(new Movie(51935, "Shooter", "2007", "Action|Drama|Thriller"));
//			moviesList.add(new Movie(52722, "Spider-Man 3", "2007", "Action|Adventure|Sci-Fi|Thriller|IMAX"));
//			moviesList.add(new Movie(54331, "You Kill Me", "2007", "Comedy|Crime|Thriller"));
//			moviesList.add(new Movie(54513, "Talk to Me", "2007", "Drama"));
//			moviesList.add(new Movie(59315, "Iron Man", "2008", "Action|Adventure|Sci-Fi"));
//			moviesList.add(new Movie(63179, "Tokyo!", "2008", "Drama"));
//			moviesList.add(new Movie(66596, "Mystery Team", "2009", "Comedy|Crime|Mystery"));
//			moviesList.get(0).setImage("resources/imgs/fastfive.jpg");
//			moviesList.get(1).setImage("resources/imgs/hangover.jpg");
//			moviesList.get(2).setImage("resources/imgs/fightclub.jpg");
//			moviesList.get(3).setImage("resources/imgs/shooter.jpg");
//			moviesList.get(4).setImage("resources/imgs/spiderman.jpg");
//			moviesList.get(5).setImage("resources/imgs/youkillme.jpg");
//			moviesList.get(6).setImage("resources/imgs/talktome.jpg");
//			moviesList.get(7).setImage("resources/imgs/ironman.jpg");
//			moviesList.get(8).setImage("resources/imgs/tokyo.jpg");
//			moviesList.get(9).setImage("resources/imgs/mysteryteam.jpg");
			load();
//			save();
			updateIds();
			computeRating();
			setRatings();
		}
		
		//fill the rating field and id for all the Movie in the list
		public void updateIds(){
			int newId = 1;
			for(Movie m : moviesList){
				m.setId(newId);
				newId++;
			}
			
		}
		
		public void setRatings(){
			for(Movie m : moviesList){
				m.calculateRating();
			}
		}
		
		// update a movie's rating using it's shown Id
		public void updateRating(int iD, double newRate){
			
			for(Movie m : moviesList){
				
				if(m.getId() == iD)
				m.updateRating(newRate);
			}
			
		}
		
		//delete a movie using movie id
		public void deleteMovie(int id){
			int counter = 0;
			for(Movie m : moviesList){
				if(m.getId() == id){
					moviesList.remove(counter);
					break;
//					m.setId(0);
				}
				counter++;
			}
			updateIds();
		}
		
		public Movie getMovie(int id){
			for(Movie m : moviesList){
				if(id == m.getId()){
					return m;
				}
			}
			return null;
		}
		
		public void addMovie(String title2, String year2, String genres2, double rating2){
			Movie newMovie = new Movie(-1, title2,year2, genres2);
			newMovie.setRating(rating2);
			moviesList.add(newMovie);
			updateIds();
			
		}
		
		public Movie search(String input){
			Movie ret = new Movie(0,"", "Movie not Found", "");
			
			for(Movie m : moviesList){
				String tit = m.getTitle().toLowerCase();
				if(tit.contains(input.toLowerCase())){
					return m;
				}
				
			}
			
			return ret;
		}
		public void sort(){
			
			moviesList.sort(Comparator.comparing(Movie::getRating));
			Collections.reverse(moviesList);
			updateIds();
		}
		
		public void computeRating(){
			
			
			Map<Integer, Integer> mIdex = new HashMap<Integer, Integer>();
			int i = 0;
			for(Movie m : moviesList) {
				mIdex.put(m.movieId, i);
				i++;	
			}
			
			
			File inFile = new File("resources/ratings.csv");
			
			
			try{
			Scanner scan = new Scanner(inFile);
			scan.useDelimiter(",");
			scan.nextLine(); //skip first line
			while(scan.hasNextLine()){
				scan.nextInt(); // skip userId
				int movId = scan.nextInt();
//				if(movId == movieId){
				if(mIdex.containsKey(movId)) {
					Movie m = moviesList.get(mIdex.get(movId));
					m.ratings = m.ratings	+	scan.nextDouble();
					m.numberOfRators ++;
					moviesList.set(mIdex.get(movId), m);
				}
			scan.nextLine();
			}
			scan.close();
			}catch(FileNotFoundException e){
				System.out.println("coudn't get ratings "+e.getMessage());
			}
		}
		
		
		
		public void load(){
			
			try{
				ObjectInputStream ois = new ObjectInputStream(new FileInputStream("resources/moviesRegistery"));
				moviesList = (List) ois.readObject();
				ois.close();
			}catch(Exception e){
				e.getMessage();
			}
			
		}
		
		public void save(){
			try{
				ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("resources/moviesRegistery"));
				oos.writeObject(moviesList);
				oos.close();
			}catch(Exception e){
				e.getMessage();
			}	
		}
		
		
		
		
		
		
}

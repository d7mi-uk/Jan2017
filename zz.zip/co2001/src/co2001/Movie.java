package co2001;

import java.io.*;
import java.util.*;
public class Movie implements Serializable {

	int id;
	int movieId;
	String title;
	String genres, year;
	double rating;
	int numberOfRators = 0;
	double ratings = 0;
	String img;
	
	public Movie (int mId, String mTitle,String mYear, String mGenres){
		
//		id = iD;
		movieId = mId;
		title = mTitle;
		genres = mGenres;
		year = mYear;
	}
	
	public Movie(){
		
	}
	
	
	
	
	public void setMovieId(int mId){
		movieId = mId;
	}
	public void setRating(double r){
		rating = r;
	}
	public void setId(int id){
		this.id = id;
	}
	public void setTitle(String title){
		this.title = title;
	}
	public void setGenres(String genres){
		this.genres = genres;
	}
	public void setImage(String img){
		this.img = img;
	}
	public void setYear(String ye){
		this.year = ye;
	}
	
	
	public int getId(){
		return id;
	}
	public int getmovieId(){
		return movieId;
	}
	public String getTitle(){
		return title;
	}
	public String getGenres(){
		return genres;
	}
	public double getRating(){
		return rating;
	}
	public String getImage(){
		return img;
	}
	public int getNumberOfRators(){
		return numberOfRators;
	}
	public String getYear(){
		return year;
	}
	
	double oldRatings = 0;
	// This method compute the aggregated rating for the movie only if it wasn't added by the user 
//	public void computeRating(){
//		File inFile = new File("resources/ratings.csv");
//		try{
//		Scanner scan = new Scanner(inFile);
//		scan.useDelimiter(",");
//		scan.nextLine(); //skip first line
//		while(scan.hasNextLine()){
//			scan.nextInt(); // skip userId
//			int movId = scan.nextInt();
//			if(movId == movieId){
//				ratings = ratings	+	scan.nextDouble();
//				numberOfRators ++;
//			}
//		scan.nextLine();
//		
//		}
//		double temp;
//		temp = (ratings/numberOfRators) * 100;
//		temp = Math.round(temp);
//		rating = temp/100;
//		scan.close();
//		}catch(FileNotFoundException e){
//			System.out.println("coudn't get ratings "+e.getMessage());
//		}
//	}
	public void calculateRating() {
		double temp;
		temp = (ratings/numberOfRators) * 100;
		temp = Math.round(temp);
		rating = temp/100;
	}
	
	public void updateRating(double newRate){
		ratings += newRate;
		numberOfRators ++;
		double temp;
		temp = (ratings/numberOfRators) * 100;
		temp = Math.round(temp);
		rating = temp/100;
	}
	
	
	
	//To be used in computeRatings()
//	public static double ratingFormat(double d) {
//	    return Math.round(d * 2) / 2.0;
//	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}

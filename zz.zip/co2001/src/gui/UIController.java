package gui;
import co2001.*;

import javafx.geometry.*;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.*;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Accordion;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.TitledPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class UIController {

	@FXML
    public Button details;
    @FXML
    public TitledPane movie1, movie2, movie3, movie4, movie5;
    @FXML
    public HBox loadsort;
    @FXML
    public VBox center;
    @FXML
    public Label id1,id2, id3, id4, id5, genres1, genres2, genres3, genres4, genres5, rating1, rating2, rating3, rating4, rating5;
    @FXML
    public TextField toSearch;
    @FXML
    public ImageView img;
    
    @FXML
    public HBox detailsBox, buttonsBox;
    @FXML
    public Label year, yearL, rators, ratorsL;
    
    MoviesManager mm = new MoviesManager();
    List<Integer> ids = new ArrayList<>();
    Movie movie = new Movie();
    boolean ready = false;
    
   Node t2, t3, t4, t5;
    
    public void load() throws Exception {
    	if(center.getChildren().size()<5){
    		center.getChildren().add(t2);
    		center.getChildren().add(t3);
    		center.getChildren().add(t4);
    		center.getChildren().add(t5);
    	}
    	details.setVisible(true);
    	detailsBox.setVisible(false);
    	buttonsBox.setVisible(false);
    	getMovies();
		int id = 0;
		//Titled pane 1
		System.out.println(mm.moviesList.size());
		id = ids.get(0);
		id1.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie1.setText(mm.getMovie(id).getTitle());
		rating1.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres1.setText(mm.getMovie(id).getGenres());
		
		//Titled pane 2
		id = ids.get(1);
		id2.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie2.setText(mm.getMovie(id).getTitle());
		rating2.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres2.setText(mm.getMovie(id).getGenres());
		//Titled pane 3
		id = ids.get(2);
		id3.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie3.setText(mm.getMovie(id).getTitle());
		rating3.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres3.setText(mm.getMovie(id).getGenres());
		
		//Titled pane 4
		id = ids.get(3);
		id4.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie4.setText(mm.getMovie(id).getTitle());
		rating4.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres4.setText(mm.getMovie(id).getGenres());
		//Titled pane 1
		id = ids.get(4);
		id5.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie5.setText(mm.getMovie(id).getTitle());
		rating5.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres5.setText(mm.getMovie(id).getGenres());
				
		FileInputStream input = new FileInputStream("resources/imgs/1.jpg");
		Image im = new Image(input);
		img.setImage(im);
		
		center.setVisible(true);
		
	}
    
	
	public void getMovies(){
		if (ready == false){
    		mm.fillList();	
    		ready = true;
    	}
		
		
		Random rand = new Random();		
		int x = 0;
		ids = new ArrayList<>();
		while(ids.size()<5){
			x = 1	+	rand.nextInt(10);
			if(!ids.contains(x))
				ids.add( x	);
		}
		
		
		
		
	
	}
	@FXML
	public TextField movieToSearch;
	
	@FXML
	public void search() throws Exception {
		
		Movie movie = mm.search(toSearch.getText());
				
			showDetails(movie);	
	}
	
	public void showDetails(Movie movie) throws Exception{
		if(center.getChildren().size()==5){
			t2 = center.getChildren().get(1);
			center.getChildren().remove(1);
			t3 = center.getChildren().get(1);
			center.getChildren().remove(1);
			t4 = center.getChildren().get(1);
			center.getChildren().remove(1);
			t5 = center.getChildren().get(1);
			center.getChildren().remove(1);
			}
			movieToEdit = movie;
			details.setVisible(true);
			id1.setText(	Integer.toString(	movie.getId()	)	);
			movie1.setText(movie.getTitle());
			rating1.setText(	Double.toString(	movie.getRating()	) );
			genres1.setText(movie.getGenres());
			rators.setText(Integer.toString(movie.getNumberOfRators()));
			year.setText(movie.getYear());
			
			if(movie.getImage()!=null){
			FileInputStream input = new FileInputStream(movie.getImage());
			Image im = new Image(input);
			img.setImage(im);
			}
			detailsBox.setVisible(true);
			buttonsBox.setVisible(true);
			details.setVisible(false);
	}
	@FXML
	public void sort(){
		mm.sort();
		Collections.sort(ids);
		int id = 0;
		//Titled pane 1
		id = ids.get(0);
		id1.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie1.setText(mm.getMovie(id).getTitle());
		rating1.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres1.setText(mm.getMovie(id).getGenres());
		
		//Titled pane 2
		id = ids.get(1);
		id2.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie2.setText(mm.getMovie(id).getTitle());
		rating2.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres2.setText(mm.getMovie(id).getGenres());
		//Titled pane 3
		id = ids.get(2);
		id3.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie3.setText(mm.getMovie(id).getTitle());
		rating3.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres3.setText(mm.getMovie(id).getGenres());
		
		//Titled pane 4
		id = ids.get(3);
		id4.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie4.setText(mm.getMovie(id).getTitle());
		rating4.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres4.setText(mm.getMovie(id).getGenres());
		//Titled pane 1
		id = ids.get(4);
		id5.setText(	Integer.toString(	mm.getMovie(id).getId()	)	);
		movie5.setText(mm.getMovie(id).getTitle());
		rating5.setText(	Double.toString(	mm.getMovie(id).getRating()	) );
		genres5.setText(mm.getMovie(id).getGenres());
				
		
		center.setVisible(true);
	}
	

	Movie movieToEdit = null;
	@FXML
	public void edit(ActionEvent event) throws Exception{
		FXMLLoader loader = new FXMLLoader(getClass().getResource("Edit.fxml"));
		Parent root = loader.load();
		EditController ec = (EditController) loader.getController();
		ec.setTitle(movieToEdit, movieToEdit.getTitle(), movieToEdit.getGenres(), movieToEdit.getYear(), movieToEdit.getImage());		
        Stage stage = new Stage();
       Scene uiScene = new Scene(root);
       stage.setTitle("Edit movie Details");
       stage.setScene(uiScene);
       stage.show();
	}
	
	@FXML
	public void delete(){
		
	}
	
	@FXML
	public void details1() throws Exception{
		Movie movie = mm.getMovie(ids.get(0));
		showDetails(movie);
	}
	
	@FXML
	public void details2() throws Exception{
		Movie movie = mm.getMovie(ids.get(1));
		showDetails(movie);
	}
	@FXML
	public void details3() throws Exception{
		Movie movie = mm.getMovie(ids.get(2));
		showDetails(movie);
	}
	@FXML
	public void details4() throws Exception{
		Movie movie = mm.getMovie(ids.get(3));
		showDetails(movie);
	}
	@FXML
	public void details5() throws Exception{
		Movie movie = mm.getMovie(ids.get(4));
		showDetails(movie);
	}
	
}

package gui;

import co2001.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.HBox;
import javafx.stage.*;

import java.io.IOException;

import javax.xml.soap.Text;

public class LoginController {

	@FXML
    public Button button;
    @FXML
    public TextField username, password;
    @FXML
    public Label message;
    String usrname, passwd;
    public HBox loadsort;
    
    public void loginUser(ActionEvent event) throws Exception{
    	
    	
    	// If registered() method returns true (the user is already in the list) then execute the following code
    	if(registered()){
    		Parent root = FXMLLoader.load(getClass().getResource("UI.fxml"));
            Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
           root.getChildrenUnmodifiable().get(1).setVisible(false);
           Scene uiScene = new Scene(root);
           stage.setTitle("Movies App");
           stage.setScene(uiScene);
           stage.show();
            
    	}
    	
    	
   }
    
    public boolean registered(){
    	
    	UsersManager um = new UsersManager();
    	//read the list from the file
    	um.read(); 
    	//user's input in username and password textFields and store them in local Strings variables
    	usrname = username.getText();
    	passwd = password.getText();
    	//If the user inputs nothing return false
    	if(usrname.equals("") || passwd.equals("")) return false; 
    	
    	for(User user : um.getUsers()){
    		//if user's input (username & password) -> matches a user's (username & password) from the list of users then return true
    		if( (user.getUserName().equals(usrname)) && (user.getPassWord().equals(passwd)) ){
    			return true;
    		}
    	}
    	
    	//At this point the user's input doesn't match what's in the list of users which means he's not registered 
    	message.setText("You're not registered");
    	return false;
    }
    
    
    
    
    
    
    public void switchToUI(ActionEvent event) throws IOException {
    	Parent root = FXMLLoader.load(getClass().getResource("UI.fxml"));
    	root.getChildrenUnmodifiable().get(1).setVisible(false);
        Scene uiScene = new Scene(root);
        Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        stage.setTitle("Movies App");
        stage.setScene(uiScene);
        stage.show();
    }
    
    


    
    public void newUser(ActionEvent event) throws Exception{
        Parent root = FXMLLoader.load(getClass().getResource("Register.fxml"));
        Scene registerScene = new Scene(root);
        Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        stage.setTitle("Register page");
        stage.setScene(registerScene);
        stage.show();
    }
    	
	
	
	
	
	
	
	
}

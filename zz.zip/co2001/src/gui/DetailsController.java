package gui;
import co2001.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

public class DetailsController {

    @FXML
    private Label id;

    @FXML
    private Label title;

    @FXML
    private Label genres;

    @FXML
    private Label rating;
    
    @FXML
    private ImageView img;
    
    @FXML
    private TextField movieToSearch;

    MoviesManager mm = new MoviesManager();
    public void start(Stage primaryStage) throws Exception {
    	Parent root = FXMLLoader.load(getClass().getResource("Details.fxml"));
    	Scene uiScene = new Scene(root);
    	primaryStage.setTitle("Movies App");
    	primaryStage.setScene(uiScene);
    	primaryStage.show();
    }
    
  
    
   
    
    @FXML
    void load(ActionEvent event) throws Exception {
    	Parent root = FXMLLoader.load(getClass().getResource("UI.fxml"));
        Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
       root.getChildrenUnmodifiable().get(1).setVisible(false);
       Scene uiScene = new Scene(root);
       stage.setTitle("Movies App");
       stage.setScene(uiScene);
       stage.show();
    	
    }

    @FXML
    public void search() {
    	String lookUP = movieToSearch.getText();
    	mm.fillList();
    	Movie movie = mm.search(lookUP);
    	id.setText(Integer.toString(movie.getId()));
    	title.setText(movie.getTitle());
    	genres.setText(movie.getGenres());
    	rating.setText(Double.toString(movie.getRating()));
    	Image im = new Image("/resources/imgs/fastfive.jpeg");
    	img.setImage(im);
    }

}

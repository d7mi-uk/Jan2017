package gui;

import java.net.URL;
import java.util.ResourceBundle;

import co2001.*;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class EditController implements Initializable {

	MoviesManager mm = new MoviesManager();
	Movie movie;
    @FXML
    private TextField title;

    @FXML
    private TextField genres;

    @FXML
    private TextField year;

    @FXML
    private TextField path;
    
    public void setTitle(Movie m, String t, String g, String y, String p){
    	title.setText(t);
    	genres.setText(g);
    	year.setText(y);
    	path.setText(p);
    	movie = m;
    }
    
    
    @FXML
    public void save(ActionEvent event) throws Exception{
    	for(Movie m: mm.moviesList){
    		if(m.equals(movie)){
    			m.setTitle(title.getText());
    			m.setGenres(genres.getText());
    			m.setYear(year.getText());
    			m.setImage(path.getText());
    			mm.save();
    		}
    	}
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.close();
    	
    }
    @FXML
    public void cancel(ActionEvent event) throws Exception{
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.close();
    }

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
    
}

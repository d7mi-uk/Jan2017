package gui;


import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.stage.Stage;

import javax.xml.soap.Text;

import co2001.UsersManager;

public class RegisterController {

	UsersManager um = new UsersManager();
	
	@FXML
    public Button button;
    @FXML
	public Label userLabel, passwdLabel1, passwdLabel2, emailLabel, ageLabel;
    @FXML
    public TextField username, password, password2, email, age;
    String user, passwd, passwd2, eMail;
    int aGe;
    
    

    public void signUp(ActionEvent event) throws Exception {
    	clear();
    user = username.getText();
    System.out.print("Register : "+user);

    passwd = password.getText();
    passwd2 = password2.getText();
    eMail = email.getText();
    try {
    aGe = Integer.parseInt(age.getText());
    }catch(Exception e) {
    	System.out.println(e.getMessage());
    }
    validity();
    if(
        	ageValidity() &&
        	emailValidity() &&
        	pwdsValidity() &&
        	pwd2Validity() &&
        	pwd1Validity() &&
        	userValidity() ) {
    	

    				um.read();
    				um.addUser(user, passwd, eMail, aGe);
    				um.write();
    				//if a user is added to the list, the scene is switched to the login page
    				
    				Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
    		        Scene registerScene = new Scene(root);
    		        Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		        stage.setTitle("Register page");
    		        stage.setScene(registerScene);
    		        stage.show();
    			}
    
    }
   	

    
    public void validity() {
    	userValidity();
    	pwd1Validity();
    	pwd2Validity();
    	pwdsValidity();
    	emailValidity();
    	ageValidity();
    }
    
    
    public boolean userValidity() {
    	if(user.equals("")) {
    		userLabel.setText("Invalid username");
    		username.requestFocus();
    		return false;
    	}else {
    		return true;
    	}
    }
    public boolean pwd1Validity() {
    	if(passwd.equals("")) {	
    		passwdLabel1.setText("Invalid password");
    		password.requestFocus();
    		return false;
    	}else {
    		return true;
    	}
    }
    public boolean pwd2Validity() {
    	if(passwd2.equals("")) {	
    		passwdLabel2.setText("Invalid password");
    		password2.requestFocus();
    		return false;
    	}else {
    		return true;
    	}
    }
    public boolean pwdsValidity() {
    	if(!passwd.equals(passwd2)) {
    		passwdLabel1.setText("Passwords don't match");
    		return false;
    	}else {
    		return true;
    	}
    }
    
    public boolean emailValidity() {
    	if(eMail.equals("")) {
    		emailLabel.setText("Invalid email");
    		email.requestFocus();
    		return false;
    	}else {
    		return true;
    	}
    }
    public boolean ageValidity() {
    	if( (1 < aGe) && (aGe < 110) ) {
    		return true;
    	} else {
    		ageLabel.setText("Invalid age");
    		age.requestFocus();
    		return false;
    	}
    }

    
    // Clears error labels
    public void clear() {
		userLabel.setText("");
		passwdLabel1.setText("");
		passwdLabel2.setText("");
		emailLabel.setText("");
		ageLabel.setText("");
    }
    
    
    // Switch the current scene from registeration scene into login scene
    public void login(ActionEvent event) throws Exception {
    	Parent root = FXMLLoader.load(getClass().getResource("Login.fxml"));
        Scene registerScene = new Scene(root);
        Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        stage.setTitle("Register page");
        stage.setScene(registerScene);
        stage.show();
   }
}
